// This will run when the page loads
window.onload = function() {
    alert("Welcome to my website!");
};

